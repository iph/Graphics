#include "Shape.h"
#include <stdio.h>
Shape::Shape(int type){
	printf("Hello world");
}

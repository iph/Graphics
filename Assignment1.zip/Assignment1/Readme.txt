/**************************************
FILE: CS1566 Readme.txt
AUTHOR: Sean Myers
EMAIL: stm52@pitt.edu
PLATFORM: linux
HOMEWORK: 1
**************************************/



Known bugs (if any): Resizing seems to screw it up..So don't resize.

Extra credit (describe what you did, if any): None at the moment.

Comments:  To compile, just 'make'. 

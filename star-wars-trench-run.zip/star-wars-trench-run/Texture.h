/*
 * Texture.h
 *
 *  Created on: Dec 10, 2011
 *      Author: sean
 */

#ifndef TEXTURE_H_
#define TEXTURE_H_

class Texture {
public:
	static unsigned loadTexBMP(char * filename);
};

#endif /* TEXTURE_H_ */

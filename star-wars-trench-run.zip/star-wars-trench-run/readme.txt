
Project: Star Wars: Adventures of John Solo.

Collaborators: Sean Myers, Matthew Becker

Controls: W- Move faster
					S - Move Slower
					A - Spin Left
					D - Spin Right
					Move mouse- Control pitch / Yaw
					Q - Quit
					Enter - Nothing.

Making the file: Just type make. For Linux only. Especially not Mac.

Running: ./intersect (included exe for ease of use)


NOTE: Make sure you put the images folder into star-wars-trench-run folder in order for it to work!!!
	

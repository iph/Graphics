/**************************************
FILE: CS1566 Project 5
AUTHOR: Sean Myers
EMAIL: seanmyers0608@gmail.com
PLATFORM: linux
HOMEWORK: 5
**************************************/

linux


Basic functionalities that my program is providing: Everything works, I think. I didn't have an example to base it off of, but I believe it is correct.
Known bugs (if any): None known...but again, what is it supposed to look like?

Potential Problems:None

Comments: None

#include "House.h"



int main(){
	
	return 0;
}

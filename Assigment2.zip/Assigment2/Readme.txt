/**************************************
FILE: CS1566 Project 2
AUTHOR: Sean Myers
EMAIL: seanmyers0608@gmail.com
PLATFORM: linux
HOMEWORK: 2
**************************************/

linux


Basic functionalities that my program is providing: Can draw shapes, draw normals of the vertices, and is colorful. Veeerrry colorful. 
(If you want to breeze through the shapes, press 1-6). 

All source files are in src, the make file libraries are based off my GLUT and openGL file locations, so you might have to rechange the libs in the makefile, but otherwise should work perfectly.

Also, question: How would one go about making the folder subsystem in src automatically create folders for each of the subclasses of a particular class? Just wondering.


Known bugs (if any): Some Vertex normals seem as if they are off, can't figure out why. 



Extra credit (describe what you did, if anything): Colors? OOP-Design? Nothing great, but just trying to grab what I can get.



Comments:  

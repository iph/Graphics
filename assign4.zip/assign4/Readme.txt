/**************************************
FILE: CS1566 Project 4
AUTHOR: Sean Myers
EMAIL: seanmyers0608@gmail.com
PLATFORM: linux
HOMEWORK: 4
**************************************/

linux


Basic functionalities that my program is providing: Everything works. No lighting

Known bugs (if any): None known.

Potential Problems: Works. Doesn't have lighting, sorry bro :(



Comments: None
